require('dotenv').config({ path: './.env' })
require('./bot')
