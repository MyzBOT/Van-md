const https = require('https')
const Stream = require('stream').Transform

const downloadFileByUrl = (fileUrl) => new Promise((resolve, reject) => {
  const data = new Stream()

  https.get(fileUrl, (response) => {
    response.on('data', (chunk) => {
      data.push(chunk)
    })

    response.on('end', () => {
      resolve(data)
    })
  }).on('error', reject)
})

module.exports = downloadFileByUrl
